/*! This file is auto-generated */
(function() {
"use strict";var wp;(wp||={}).warning=(()=>{var i=Object.defineProperty;var a=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var l=Object.prototype.hasOwnProperty;var c=(r,t)=>{for(var n in t)i(r,n,{get:t[n],enumerable:!0})},d=(r,t,n,u)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of f(t))!l.call(r,o)&&o!==n&&i(r,o,{get:()=>t[o],enumerable:!(u=a(t,o))||u.enumerable});return r};var h=r=>d(i({},"__esModule",{value:!0}),r);var p={};c(p,{default:()=>g});var e=new Set;function w(){return!1}function g(r){if(w()&&!e.has(r)){console.warn(r);try{throw Error(r)}catch{}e.add(r)}}return h(p);})();
if (typeof wp.warning === 'object' && wp.warning.default) { wp.warning = wp.warning.default; }
(window.wp ||= {}).warning = wp.warning;
})();

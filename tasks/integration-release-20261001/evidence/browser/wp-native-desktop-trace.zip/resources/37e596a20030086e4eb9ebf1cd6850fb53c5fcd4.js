/*! This file is auto-generated */
(function() {
"use strict";var wp;(wp||={}).autop=(()=>{var l=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var b=Object.prototype.hasOwnProperty;var $=(e,n)=>{for(var r in n)l(e,r,{get:n[r],enumerable:!0})},w=(e,n,r,c)=>{if(n&&typeof n=="object"||typeof n=="function")for(let i of u(n))!b.call(e,i)&&i!==r&&l(e,i,{get:()=>n[i],enumerable:!(c=f(n,i))||c.enumerable});return e};var v=e=>w(l({},"__esModule",{value:!0}),e);var S={};$(S,{autop:()=>R,removep:()=>j});var k=(()=>{let c="(<("+("(?=!--|!\\[CDATA\\[)((?=!-)"+"!(?:-(?!->)[^\\-]*)*(?:-->)?"+"|"+"!\\[CDATA\\[[^\\]]*(?:](?!]>)[^\\]]*)*?(?:]]>)?"+")")+"|[^>]*>?))";return new RegExp(c)})();function O(e){let n=[],r=e,c;for(;c=r.match(k);){let i=c.index;n.push(r.slice(0,i)),n.push(c[0]),r=r.slice(i+c[0].length)}return r.length&&n.push(r),n}function E(e,n){let r=O(e),c=!1,i=Object.keys(n);for(let s=1;s<r.length;s+=2)for(let a=0;a<i.length;a++){let p=i[a];if(r[s].indexOf(p)!==-1){r[s]=r[s].replace(new RegExp(p,"g"),n[p]),c=!0;break}}return c&&(e=r.join("")),e}function R(e,n=!0){let r=[];if(e.trim()==="")return"";if(e=e+`
`,e.indexOf("<pre")!==-1){let s=e.split("</pre>"),a=s.pop();e="";for(let p=0;p<s.length;p++){let o=s[p],g=o.indexOf("<pre");if(g===-1){e+=o;continue}let d="<pre wp-pre-tag-"+p+"></pre>";r.push([d,o.substr(g)+"</pre>"]),e+=o.substr(0,g)+d}e+=a}e=e.replace(/<br\s*\/?>\s*<br\s*\/?>/g,`

`);let c="(?:table|thead|tfoot|caption|col|colgroup|tbody|tr|td|th|div|dl|dd|dt|ul|ol|li|pre|form|map|area|blockquote|address|math|style|p|h[1-6]|hr|fieldset|legend|section|article|aside|hgroup|header|footer|nav|figure|figcaption|details|menu|summary)";e=e.replace(new RegExp("(<"+c+"[\\s/>])","g"),`

$1`),e=e.replace(new RegExp("(</"+c+">)","g"),`$1

`),e=e.replace(/\r\n|\r/g,`
`),e=E(e,{"\n":" <!-- wpnl --> "}),e.indexOf("<option")!==-1&&(e=e.replace(/\s*<option/g,"<option"),e=e.replace(/<\/option>\s*/g,"</option>")),e.indexOf("</object>")!==-1&&(e=e.replace(/(<object[^>]*>)\s*/g,"$1"),e=e.replace(/\s*<\/object>/g,"</object>"),e=e.replace(/\s*(<\/?(?:param|embed)[^>]*>)\s*/g,"$1")),(e.indexOf("<source")!==-1||e.indexOf("<track")!==-1)&&(e=e.replace(/([<\[](?:audio|video)[^>\]]*[>\]])\s*/g,"$1"),e=e.replace(/\s*([<\[]\/(?:audio|video)[>\]])/g,"$1"),e=e.replace(/\s*(<(?:source|track)[^>]*>)\s*/g,"$1")),e.indexOf("<figcaption")!==-1&&(e=e.replace(/\s*(<figcaption[^>]*>)/,"$1"),e=e.replace(/<\/figcaption>\s*/,"</figcaption>")),e=e.replace(/\n\n+/g,`

`);let i=e.split(/\n\s*\n/).filter(Boolean);return e="",i.forEach(s=>{e+="<p>"+s.replace(/^\n*|\n*$/g,"")+`</p>
`}),e=e.replace(/<p>\s*<\/p>/g,""),e=e.replace(/<p>([^<]+)<\/(div|address|form)>/g,"<p>$1</p></$2>"),e=e.replace(new RegExp("<p>\\s*(</?"+c+"[^>]*>)\\s*</p>","g"),"$1"),e=e.replace(/<p>(<li.+?)<\/p>/g,"$1"),e=e.replace(/<p><blockquote([^>]*)>/gi,"<blockquote$1><p>"),e=e.replace(/<\/blockquote><\/p>/g,"</p></blockquote>"),e=e.replace(new RegExp("<p>\\s*(</?"+c+"[^>]*>)","g"),"$1"),e=e.replace(new RegExp("(</?"+c+"[^>]*>)\\s*</p>","g"),"$1"),n&&(e=e.replace(/<(script|style).*?<\/\\1>/g,s=>s[0].replace(/\n/g,"<WPPreserveNewline />")),e=e.replace(/<br>|<br\/>/g,"<br />"),e=e.replace(/(<br \/>)?\s*\n/g,(s,a)=>a?s:`<br />
`),e=e.replace(/<WPPreserveNewline \/>/g,`
`)),e=e.replace(new RegExp("(</?"+c+"[^>]*>)\\s*<br />","g"),"$1"),e=e.replace(/<br \/>(\s*<\/?(?:p|li|div|dl|dd|dt|th|pre|td|ul|ol)[^>]*>)/g,"$1"),e=e.replace(/\n<\/p>$/g,"</p>"),r.forEach(s=>{let[a,p]=s;e=e.replace(a,()=>p)}),e.indexOf("<!-- wpnl -->")!==-1&&(e=e.replace(/\s?<!-- wpnl -->\s?/g,`
`)),e}function j(e){let n="blockquote|ul|ol|li|dl|dt|dd|table|thead|tbody|tfoot|tr|th|td|h[1-6]|fieldset|figure",r=n+"|div|p",c=n+"|pre",i=[],s=!1,a=!1;return e?((e.indexOf("<script")!==-1||e.indexOf("<style")!==-1)&&(e=e.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/g,p=>(i.push(p),"<wp-preserve>"))),e.indexOf("<pre")!==-1&&(s=!0,e=e.replace(/<pre[^>]*>[\s\S]+?<\/pre>/g,p=>(p=p.replace(/<br ?\/?>(\r\n|\n)?/g,"<wp-line-break>"),p=p.replace(/<\/?p( [^>]*)?>(\r\n|\n)?/g,"<wp-line-break>"),p.replace(/\r?\n/g,"<wp-line-break>")))),e.indexOf("[caption")!==-1&&(a=!0,e=e.replace(/\[caption[\s\S]+?\[\/caption\]/g,p=>p.replace(/<br([^>]*)>/g,"<wp-temp-br$1>").replace(/[\r\n\t]+/,""))),e=e.replace(new RegExp("\\s*</("+r+")>\\s*","g"),`</$1>
`),e=e.replace(new RegExp("\\s*<((?:"+r+")(?: [^>]*)?)>","g"),`
<$1>`),e=e.replace(/(<p [^>]+>[\s\S]*?)<\/p>/g,"$1</p#>"),e=e.replace(/<div( [^>]*)?>\s*<p>/gi,`<div$1>

`),e=e.replace(/\s*<p>/gi,""),e=e.replace(/\s*<\/p>\s*/gi,`

`),e=e.replace(/\n[\s\u00a0]+\n/g,`

`),e=e.replace(/(\s*)<br ?\/?>\s*/gi,(p,o)=>o&&o.indexOf(`
`)!==-1?`

`:`
`),e=e.replace(/\s*<div/g,`
<div`),e=e.replace(/<\/div>\s*/g,`</div>
`),e=e.replace(/\s*\[caption([^\[]+)\[\/caption\]\s*/gi,`

[caption$1[/caption]

`),e=e.replace(/caption\]\n\n+\[caption/g,`caption]

[caption`),e=e.replace(new RegExp("\\s*<((?:"+c+")(?: [^>]*)?)\\s*>","g"),`
<$1>`),e=e.replace(new RegExp("\\s*</("+c+")>\\s*","g"),`</$1>
`),e=e.replace(/<((li|dt|dd)[^>]*)>/g," 	<$1>"),e.indexOf("<option")!==-1&&(e=e.replace(/\s*<option/g,`
<option`),e=e.replace(/\s*<\/select>/g,`
</select>`)),e.indexOf("<hr")!==-1&&(e=e.replace(/\s*<hr( [^>]*)?>\s*/g,`

<hr$1>

`)),e.indexOf("<object")!==-1&&(e=e.replace(/<object[\s\S]+?<\/object>/g,p=>p.replace(/[\r\n]+/g,""))),e=e.replace(/<\/p#>/g,`</p>
`),e=e.replace(/\s*(<p [^>]+>[\s\S]*?<\/p>)/g,`
$1`),e=e.replace(/^\s+/,""),e=e.replace(/[\s\u00a0]+$/,""),s&&(e=e.replace(/<wp-line-break>/g,`
`)),a&&(e=e.replace(/<wp-temp-br([^>]*)>/g,"<br$1>")),i.length&&(e=e.replace(/<wp-preserve>/g,()=>i.shift())),e):""}return v(S);})();
(window.wp ||= {}).autop = wp.autop;
})();

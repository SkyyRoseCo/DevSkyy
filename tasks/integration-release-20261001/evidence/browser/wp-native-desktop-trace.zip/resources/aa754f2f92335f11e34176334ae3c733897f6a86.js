/*! This file is auto-generated */
(function() {
"use strict";var wp;(wp||={}).htmlEntities=(()=>{var r=Object.defineProperty;var a=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var u=(e,t)=>{for(var i in t)r(e,i,{get:t[i],enumerable:!0})},f=(e,t,i,c)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of d(t))!m.call(e,o)&&o!==i&&r(e,o,{get:()=>t[o],enumerable:!(c=a(t,o))||c.enumerable});return e};var x=e=>f(r({},"__esModule",{value:!0}),e);var T={};u(T,{decodeEntities:()=>p});var n;function p(e){if(typeof e!="string"||e.indexOf("&")===-1)return e;n===void 0&&(document.implementation&&document.implementation.createHTMLDocument?n=document.implementation.createHTMLDocument("").createElement("textarea"):n=document.createElement("textarea")),n.innerHTML=e;let t=n.textContent??"";return n.innerHTML="",t}return x(T);})();
(window.wp ||= {}).htmlEntities = wp.htmlEntities;
})();
